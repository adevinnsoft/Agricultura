﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Asociado_Default : System.Web.UI.Page
{
    public string Datax = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        string fecha = (string)Session["fecha"];
        string idgreenHouse = (string)Session["idgreenhouse"];

        Dictionary<string, object> parameters2 = new System.Collections.Generic.Dictionary<string, object>();
        parameters2.Add("@funcion", 7);
        parameters2.Add("@fecha", fecha);
        parameters2.Add("@idgreenHouse", idgreenHouse);

 
        DataTable dt3 = DataAccess.executeStoreProcedureDataTableNew("spr_rpt_DevExtreme", parameters2, "HarvestDBConnectionString");
        Datax = JsonConvert.SerializeObject(dt3);

        
    
    }
}