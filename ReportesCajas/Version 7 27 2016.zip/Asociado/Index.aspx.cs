﻿using Newtonsoft.Json;
using System.Web.Services;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;


public partial class _Default : System.Web.UI.Page 
{
    public string Datax = "";
    public string Semana = "";
    public string Variety = "";
    public string Cajas = "";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        {
            Dictionary<string, object> parameters2 = new System.Collections.Generic.Dictionary<string, object>();
            parameters2.Add("@funcion", 4);

            DataTable dt3 = DataAccess.executeStoreProcedureDataTableNew("spr_rpt_DevExtreme", parameters2, "HarvestDBConnectionString");
            DropDrownPlanta.DataSource = dt3;
            DropDrownPlanta.DataTextField = "Name";
            DropDrownPlanta.DataValueField = "farm";
            DropDrownPlanta.DataBind();

            fecha.Text = DateTime.Today.ToString("yyyy-MM-dd");

        }////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
       
           // DropDownListInvernadero.SelectedValue =
                string x = (string)Session["invernadero"];
       
      
    }
    protected void DropDrownPlanta_SelectedIndexChanged(object sender, EventArgs e)
    {
        Dictionary<string, object> parameters2 = new System.Collections.Generic.Dictionary<string, object>();
        parameters2.Add("@funcion", 5);
        parameters2.Add("@idFarm", DropDrownPlanta.SelectedValue);
        parameters2.Add("@fecha", fecha.Text);

        DataTable dt3 = DataAccess.executeStoreProcedureDataTableNew("spr_rpt_DevExtreme", parameters2, "HarvestDBConnectionString");
        
        DropDownListInvernadero.DataSource = dt3;
        DropDownListInvernadero.DataTextField = "Greenhouse";
        DropDownListInvernadero.DataValueField = "idGreenHouse";
        DropDownListInvernadero.DataBind();
     ////////////////////////////////////////////////////////////
        Dictionary<string, object> parametersx2 = new System.Collections.Generic.Dictionary<string, object>();
        parametersx2.Add("@funcion", 6);
        parametersx2.Add("@idgreenHouse", DropDownListInvernadero.SelectedValue);

        DataTable dtx3 = DataAccess.executeStoreProcedureDataTableNew("spr_rpt_DevExtreme", parametersx2, "HarvestDBConnectionString");
        DropDownListLider.DataSource = dtx3;
        DropDownListLider.DataTextField = "Lider";
        DropDownListLider.DataValueField = "idGreenHouse";
        DropDownListLider.DataBind();

        TablaPivot.Src = "";

        SemanaLabel.Text = "";
        variedad.Text = "";
        tCajas.Text = "";
    }
    protected void DropDownListInvernadero_SelectedIndexChanged(object sender, EventArgs e)
    {
        Dictionary<string, object> parameters2 = new System.Collections.Generic.Dictionary<string, object>();
        parameters2.Add("@funcion", 6);
        parameters2.Add("@idgreenHouse", DropDownListInvernadero.SelectedValue);

        DataTable dt3 = DataAccess.executeStoreProcedureDataTableNew("spr_rpt_DevExtreme", parameters2, "HarvestDBConnectionString");
        DropDownListLider.DataSource = dt3;
        DropDownListLider.DataTextField = "Lider";
        DropDownListLider.DataValueField = "idGreenHouse";
        DropDownListLider.DataBind();

        Session["invernadero"] = DropDownListInvernadero.SelectedValue;
        TablaPivot.Src = "";
        SemanaLabel.Text = "";
        variedad.Text = "";
        tCajas.Text = "";
    }

    protected void fecha_TextChanged(object sender, EventArgs e)
    {
        Dictionary<string, object> parameters2 = new System.Collections.Generic.Dictionary<string, object>();
        parameters2.Add("@funcion", 5);
        parameters2.Add("@idFarm", DropDrownPlanta.SelectedValue);
        parameters2.Add("@fecha", fecha.Text);

        DataTable dt3 = DataAccess.executeStoreProcedureDataTableNew("spr_rpt_DevExtreme", parameters2, "HarvestDBConnectionString");
        DropDownListInvernadero.DataSource = dt3;
        DropDownListInvernadero.DataTextField = "Greenhouse";
        DropDownListInvernadero.DataValueField = "idGreenHouse";
        DropDownListInvernadero.DataBind();
        ////////////////////////////////////////////////////////////
        Dictionary<string, object> parametersx2 = new System.Collections.Generic.Dictionary<string, object>();
        parametersx2.Add("@funcion", 6);
        parametersx2.Add("@idgreenHouse", DropDownListInvernadero.SelectedValue);

        DataTable dtx3 = DataAccess.executeStoreProcedureDataTableNew("spr_rpt_DevExtreme", parametersx2, "HarvestDBConnectionString");
        DropDownListLider.DataSource = dtx3;
        DropDownListLider.DataTextField = "Lider";
        DropDownListLider.DataValueField = "idGreenHouse";
        DropDownListLider.DataBind();

        TablaPivot.Src = "";
        SemanaLabel.Text = "";
        variedad.Text = "";
        tCajas.Text = "";
        
    }
    protected void Generar_Click(object sender, EventArgs e)
    {
        string fechaFolio = fecha.Text;
        if ( DropDownListInvernadero.SelectedIndex>= 0)
        {
            Dictionary<string, object> parameters3 = new System.Collections.Generic.Dictionary<string, object>();
            parameters3.Add("@funcion", 8);
            parameters3.Add("@fecha", fechaFolio);
            parameters3.Add("@idgreenHouse", DropDownListInvernadero.SelectedValue);


            DataTable dt = DataAccess.executeStoreProcedureDataTableNew("spr_rpt_DevExtreme", parameters3, "HarvestDBConnectionString");
            SemanaLabel.Text = dt.Rows[0]["WeekShort"].ToString();
            variedad.Text = dt.Rows[0]["Variety"].ToString();
            tCajas.Text = dt.Rows[0]["cajas"].ToString();


            Session["fecha"] = fechaFolio;
            Session["idgreenhouse"] = DropDownListInvernadero.SelectedValue;
            TablaPivot.Src = "Asociado.aspx";
        }
        //else {
        //    msj.Text = "Faltan Datos...";
        //}
        
    }
}
