﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Asociado_Default : System.Web.UI.Page
{
    public string Datax = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        string INV = Request.QueryString["Invernadero"];
        Dictionary<string, object> parameters2 = new System.Collections.Generic.Dictionary<string, object>();
        parameters2.Add("@funcion", 3);
        parameters2.Add("@Inv", INV);

        DataTable dt3 = DataAccess.executeStoreProcedureDataTableNew("spr_rpt_DevExtreme", parameters2, "HarvestDBConnectionString");
        Datax = JsonConvert.SerializeObject(dt3);
    }
}