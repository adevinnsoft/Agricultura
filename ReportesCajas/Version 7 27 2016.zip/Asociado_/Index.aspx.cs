﻿using Newtonsoft.Json;
using System.Web.Services;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class _Default : System.Web.UI.Page 
{
    public string Datax = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        //string fm = Request.QueryString["idFarm"];
        //int SF = Convert.ToInt32(Request.QueryString["SemanaFin"]);

        Dictionary<string, object> parameters2 = new System.Collections.Generic.Dictionary<string, object>();
        parameters2.Add("@funcion", 2);
     

        DataTable dt3 = DataAccess.executeStoreProcedureDataTableNew("spr_rpt_DevExtreme", parameters2, "HarvestDBConnectionString");
        Datax = JsonConvert.SerializeObject(dt3);
         
     }
}
